$(document).ready(function(e){
	////////////////One Button///////////////////// 
	$('#One').click(function (e){
		$('#blackBox' ).animate({
			paddingLeft: '77%'
			});
			// secerey nav
			$('#sean').fadeIn();
			//backbutton
			$('#thebonds').fadeIn();
			$('#backTop').fadeOut();
			// the bonds
			$('#Two').fadeOut();
			$('#Three').fadeOut();
			$('#Four').fadeOut();
			$('#Five').fadeOut();
			$('#Six').fadeOut();
			
			
				$('#geo').fadeOut();
				$('#tim').fadeOut();
				$('#rog').fadeOut();
				$('#pie').fadeOut();
				$('#dan').fadeOut();
				
				$('#Soverall').show();
	$('#Goverall').hide();
	$('#Toverall').hide();
	$('#Roverall').hide();
	$('#Poverall').hide();
	$('#Doverall').hide();
				
				
				
				
	
			
			
			
	});
		//Images
		$('#killS').click(function(e){
			$('#SeanKill').slideToggle();
			
	$('#upSK').fadeToggle();
	$('#downSK').fadeToggle();
	
			});
			
			$('#SR').click(function(e){
				$('#rate').slideToggle();
				$('#upSR').fadeToggle();
				$('#downSR').fadeToggle();
				});
				
				$('#Sgad').click(function(e){
				$('#Sgadget').slideToggle();
				$('#upSG').fadeToggle();
				$('#downSG').fadeToggle();
				});
				$('#girlS').click(function(e){
					$('#Sgirl').slideToggle();
					$('#upSGR').fadeToggle();
					$('#downSGR').fadeToggle();
					});
					$('#SVillian').click(function(e){
					$('#VS').slideToggle();
					$('#upSV').fadeToggle();
					$('#downSV').fadeToggle();
					});
	//////////TWO BUTTON/////////////
	$('#Two').click(function(e){
		$('#blackBox').animate({
			paddingLeft: '725px'
			});
			//seceret nav
			$('#geo').fadeIn();
			//backbutton
			$('#thebonds').fadeIn();
			$('#backTop').fadeOut();
			//jame bonds	
			$('#One' ).fadeOut();
			$('#Three' ).fadeOut();
			$('#Four' ).fadeOut();
			$('#Five' ).fadeOut();
			$('#Six' ).fadeOut();
			
			$('#sean').fadeOut();
				
				$('#tim').fadeOut();
				$('#rog').fadeOut();
				$('#pie').fadeOut();
				$('#dan').fadeOut();
				
				$('#Soverall').hide();
	$('#Goverall').show();
	$('#Toverall').hide();
	$('#Roverall').hide();
	$('#Poverall').hide();
	$('#Doverall').hide();
			
		});
		//closes Two
		//Images
		$('#killG').click(function(e){
			$('#SeankillG').slideToggle();
			$('#upGK').fadeToggle();
					$('#downGK').fadeToggle();
			});
			
			$('#ga').click(function(e){
				$('#rateG').slideToggle();
				$('#upGR').fadeToggle();
					$('#downGR').fadeToggle();
				});
				
				$('#Ggad').click(function(e){
				$('#GGad').slideToggle();
				$('#upGG').fadeToggle();
					$('#downGG').fadeToggle();
				});
				$('#gvillian').click(function(e){
					$('#GV').slideToggle();
					$('#upGV').fadeToggle();
					$('#downGV').fadeToggle();
					});
					$('#ggirl').click(function(e){
					$('#Ggirl').slideToggle();
					$('#upGGR').fadeToggle();
					$('#downGGR').fadeToggle();
					});
		
		//ButtonThree//////////
		$('#Three').click(function(e){
		$('#blackBox').animate({
			paddingLeft: '725px'
			});
			//seceret nav 
			$('#tim').fadeIn();
			//backbutton
			$('#thebonds').fadeIn();
			$('#backTop').fadeOut();
			//jame bonds	
			$('#One' ).fadeOut();
			$('#Two' ).fadeOut();
			$('#Four' ).fadeOut();
			$('#Five' ).fadeOut();
			$('#Six' ).fadeOut();
			
			$('#sean').fadeOut();
				$('#geo').fadeOut();
				
				$('#rog').fadeOut();
				$('#pie').fadeOut();
				$('#dan').fadeOut();
				
				$('#Soverall').hide();
	$('#Goverall').hide();
	$('#Toverall').show();
	$('#Roverall').hide();
	$('#Poverall').hide();
	$('#Doverall').hide();
			
		});
		//closes Three
		//Images
		$('#killT').click(function(e){
			$('#SeankillT').slideToggle();
			$('#upTK').fadeToggle();
					$('#downTK').fadeToggle();
			});
			
			
			$('#tgad').click(function(e){
				$('#Tgad').slideToggle();
				$('#upTG').fadeToggle();
					$('#downTG').fadeToggle();
				});
				
				$('#TR').click(function(e){
				$('#rateT').slideToggle();
				$('#upTR').fadeToggle();
					$('#downTR').fadeToggle();
				});
				
				$('#VT').click(function(e){
					$('#TV').slideToggle();
					$('#upTV').fadeToggle();
					$('#downTV').fadeToggle();
					});
					$('#GT').click(function(e){
					$('#Tg').slideToggle();
					$('#upTGR').fadeToggle();
					$('#downTGR').fadeToggle();
					});
		
		//Button Four
		$('#Four').click(function(e){
		$('#blackBox').animate({
			paddingLeft: '725px'
			});
			//seceret nav 
			$('#rog').fadeIn();
			//backbutton
			$('#thebonds').fadeIn();
			$('#backTop').fadeOut();
			//jame bonds	
			$('#One' ).fadeOut();
			$('#Three' ).fadeOut();
			$('#Two' ).fadeOut();
			$('#Five' ).fadeOut();
			$('#Six' ).fadeOut();
			
			$('#sean').fadeOut();
				$('#geo').fadeOut();
				$('#tim').fadeOut();
				
				$('#pie').fadeOut();
				$('#dan').fadeOut();
				
				$('#Soverall').hide();
	$('#Goverall').hide();
	$('#Toverall').hide();
	$('#Roverall').show();
	$('#Poverall').hide();
	$('#Doverall').hide();
			
		});
		//closes Four
		//Images
		$('#killR').click(function(e){
			$('#SeanKillR').slideToggle();
			$('#upRK').fadeToggle();
					$('#downRK').fadeToggle();
			});
			
			$('#rgad').click(function(e){
				$('#Rgad').slideToggle();
				$('#upRG').fadeToggle();
					$('#downRG').fadeToggle();
				});
				
				$('#RA').click(function(e){
				$('#ra').slideToggle();
				$('#upRR').fadeToggle();
					$('#downRR').fadeToggle();
				});
				$('#RV').click(function(e){
					$('#rv').slideToggle();
					$('#upRV').fadeToggle();
					$('#downRV').fadeToggle();
					});
					$('#Rgirl').click(function(e){
					$('#rgirl').slideToggle();
					$('#upRGR').fadeToggle();
					$('#downRGR').fadeToggle();
					});
		
		//Button Five
		$('#Five').click(function(e){
		$('#blackBox').animate({
			paddingLeft: '725px'
			});
			//seceret nav 
			$('#pie').fadeIn();
			//backbutton
			$('#thebonds').fadeIn();
			$('#backTop').fadeOut();
			//jame bonds	
			$('#One' ).fadeOut();
			$('#Three' ).fadeOut();
			$('#Four' ).fadeOut();
			$('#Two' ).fadeOut();
			$('#Six' ).fadeOut();
			
			$('#sean').fadeOut();
				$('#geo').fadeOut();
				$('#tim').fadeOut();
				$('#rog').fadeOut();
				
				$('#dan').fadeOut();
				
				$('#Soverall').hide();
	$('#Goverall').hide();
	$('#Toverall').hide();
	$('#Roverall').hide();
	$('#Poverall').show();
	$('#Doverall').hide();
			
		});
		//closes Five
		//Images
		$('#killP').click(function(e){
			$('#SeanKillP').slideToggle();
			$('#upPK').fadeToggle();
					$('#downPK').fadeToggle();
			});
		
			$('#pgad').click(function(e){
				$('#PG').slideToggle();
				
				$('#upPG').fadeToggle();
					$('#downPG').fadeToggle();
				});
				
				$('#AP').click(function(e){
				$('#prate').slideToggle();
				
				$('#upPR').fadeToggle();
					$('#downPR').fadeToggle();
				});
				$('#PV').click(function(e){
					$('#pv').slideToggle();
					
					$('#upPV').fadeToggle();
					$('#downPV').fadeToggle();
					});
					$('#pgirl').click(function(e){
					$('#Pgirl').slideToggle();
					
					$('#upPGR').fadeToggle();
					$('#downPGR').fadeToggle();
					});
	
		//Button Six
		$('#Six').click(function(e){
		$('#blackBox').animate({
			paddingLeft: '725px'
			});
			//seceret nav 
			$('#dan').fadeIn();
			//backbutton
			$('#thebonds').fadeIn();
			$('#backTop').fadeOut();
			//jame bonds	
			$('#One' ).fadeOut();
			$('#Three' ).fadeOut();
			$('#Four' ).fadeOut();
			$('#Five' ).fadeOut();
			$('#Two' ).fadeOut();
			
			$('#sean').fadeOut();
				$('#geo').fadeOut();
				$('#tim').fadeOut();
				$('#rog').fadeOut();
				$('#pie').fadeOut();
				
				$('#Soverall').hide();
	$('#Goverall').hide();
	$('#Toverall').hide();
	$('#Roverall').hide();
	$('#Poverall').hide();
	$('#Doverall').show();
				
			
		});
		//closes Six
		//Images
		$('#killD').click(function(e){
			$('#SeankillD').slideToggle();
			
			$('#upDK').fadeToggle();
					$('#downDK').fadeToggle();
			});
		
			$('#Dgad').click(function(e){
				$('#dgad').slideToggle();
				
				$('#upDG').fadeToggle();
					$('#downDG').fadeToggle();
				});
				
				$('#DR').click(function(e){
				$('#rateD').slideToggle();
				
				$('#upDR').fadeToggle();
					$('#downDR').fadeToggle();
				});
				
				$('#DV').click(function(e){
					$('#dv').slideToggle();
					
					$('#upDV').fadeToggle();
					$('#downDV').fadeToggle();
					});
					$('#dg').click(function(e){
					$('#dgirl').slideToggle();
					
					$('#upDGR').fadeToggle();
					$('#downDGR').fadeToggle();
					});
		
		
		
		//backButton for blackBox
		$('#thebonds').hide();
		$('#thebonds').click(function(e){
			
			$('#blackBox').animate({
				paddingLeft: '0px'
				}, 500);
				//back
				$('#thebonds').fadeOut();
				//jame bonds
				$('#One').fadeIn();
				$('#Two').fadeIn();
				$('#Three').fadeIn();
				$('#Four').fadeIn();
				$('#Five').fadeIn();
				$('#Six').fadeIn();
				
				//SECRET NAVS
				$('#sean').fadeOut();
				$('#geo').fadeOut();
				$('#tim').fadeOut();
				$('#rog').fadeOut();
				$('#pie').fadeOut();
				$('#dan').fadeOut();
				
				$('#backTop').fadeOut();
				
				
				//bars 
								
			});
			//MINI NAV FOR INFO///////////////
			$('#sean').hide();	
			$('#geo').hide();
			$('#tim').hide();
			$('#rog').hide();
			$('#pie').hide();
			$('#dan').hide();
			
			
				
				
				
				
		$(document).ready(function() {
   $('a[href*=#nav]').bind('click', function(e) {
	e.preventDefault(); //prevent the "normal" behaviour which would be a "hard" jump

	var target = $(this).attr("href"); //Get the target

	// perform animated scrolling by getting top-position of target-element and set it as scroll target
	$('html, body').stop().animate({ scrollTop: $(target).offset().top }, 700, function() {
	     location.hash = target;  //attach the hash (#jumptarget) to the pageurl
	});

	return false;
   });
});
		//responsive attampet
		//bars for Sean 
	$(window).bind("scroll", function(){
		if ($(window).scrollTop() > 2000 && $(window).width() >=900){
			
			$('#drNo').stop().animate({
				paddingLeft: '298px'
				}, 500);
				$('#S1').fadeIn();
			
			}else {
				$('.r').stop().animate({
					paddingLeft: '0px'
					})
				}
			
		});
		
	$(window).bind("scroll", function(){
		if ($(window).scrollTop() >= 2000 && $(window).width() >=900){		
		
			$('#russia').stop().animate({
				paddingLeft: '296px'
				}, 600);
				
				$('#S2').fadeIn();
			}
	});
		
	$(window).bind("scroll", function(){
		if ($(window).scrollTop() >= 2000 && $(window).width() >=900){			
		
			$('#goldf').stop().animate({
				paddingLeft: '296px'
				}, 700);
				
				$('#S3').fadeIn();
			}
		});
		
		$(window).bind("scroll", function(){
	if ($(window).scrollTop() >= 2000 && $(window).width() >=900){
		
			$('#ball').stop().animate({
				paddingLeft: '285px'
				}, 800);
				$('#S4').fadeIn();
			} 
		});
		
		$(window).bind("scroll", function(){
	if ($(window).scrollTop() >= 2000 && $(window).width() >=900){		
		
			$('#liveT').stop().animate({
				paddingLeft: '270px'
				}, 900);
				$('#S5').fadeIn();
			}
			});
			
		
		$(window).bind("scroll", function(){
	if ($(window).scrollTop() >= 2000 && $(window).width() >=900){
	
			$('#diamon').stop().animate({
				paddingLeft: '264px'
				}, 1000);
				$('#S6').fadeIn();
	}
	
	});	
			
		/////bars for George
		$(window).bind("scroll", function(){
	if ($(window).scrollTop() >= 2000 && $(window).width() >=900){
			$('#on').stop().animate({
				paddingLeft: '281px'
				});
			$('#G1').fadeIn();
			}
		});				
		//////////bars for Tim
		$(window).bind("scroll", function(){
	if ($(window).scrollTop() >= 2000 && $(window).width() >=900){
		$('#tld').stop().animate({
			paddingLeft: '275px'
			}, 500);
			$('#T1').fadeIn();
			}
		});
		
		$(window).bind("scroll", function(){
	if ($(window).scrollTop() >= 2000 && $(window).width() >=900){
		
			$('#ltk').stop().animate({
				paddingLeft: '274px'
				}, 600);
				$('#T2').fadeIn();
				}
			});
		
		
		/////////////bars for Roger
		$(window).bind("scroll", function(){
	if ($(window).scrollTop() >= 2000 && $(window).width() >=900){
		
			$('#lld').stop().animate({
				paddingLeft: '265px'
				}, 500);
				$('#R1').fadeIn();
				}
			});
		
		$(window).bind("scroll", function(){
	if ($(window).scrollTop() >= 2000 && $(window).width() >=900){
		
			$('#tmwtgg').stop().animate({
				paddingLeft: '246px'
				}, 600);
				$('#R2').fadeIn();
				}
			});	
		
		$(window).bind("scroll", function(){
	if ($(window).scrollTop() >= 2000 && $(window).width() >=900){
		
			$('#tswlm').stop().animate({
				paddingLeft: '278px'
				}, 700);
				$('#R3').fadeIn();
				}
			});	
		$(window).bind("scroll", function(){
	if ($(window).scrollTop() >= 2000 && $(window).width() >=900){	
		
			$('#m').stop().animate({
				paddingLeft: '262px'
				}, 800);
				$('#R4').fadeIn();
				}
			});	
		$(window).bind("scroll", function(){
	if ($(window).scrollTop() >= 2000 && $(window).width() >=900){
		
			$('#fyeo').stop().animate({
				paddingLeft: '273px'
				}, 900);
				$('#R5').fadeIn();
				}
			});	
		$(window).bind("scroll", function(){
	if ($(window).scrollTop() >= 2000 && $(window).width() >=900){
		
			$('#oct').stop().animate({
				paddingLeft: '243px'
				}, 1000);
				$('#R6').fadeIn();
				}
			});
		$(window).bind("scroll", function(){
	if ($(window).scrollTop() >= 2000 && $(window).width() >=900){
		
			$('#avtk').stop().animate({
				paddingLeft: '236px'
				}, 1100);
				$('#R7').fadeIn();
				}
			});		
			
			//////Pierce bars
			$(window).bind("scroll", function(){
	if ($(window).scrollTop() >= 2000 && $(window).width() >=900){
			
			$('#g').stop().animate({
				paddingLeft: '282px'
				}, 500);
				$('#P1').fadeIn();
				}
			});	
			$(window).bind("scroll", function(){
	if ($(window).scrollTop() >= 2000 && $(window).width() >=900){
			
			$('#tnd').stop().animate({
				paddingLeft: '257px'
				}, 600);
				$('#P2').fadeIn();
				}
			});	
			$(window).bind("scroll", function(){
	if ($(window).scrollTop() >= 2000 && $(window).width() >=900){
			
			$('#twine').stop().animate({
				paddingLeft: '251px'
				}, 700);
				$('#P3').fadeIn();
				}
			});	
			
			$(window).bind("scroll", function(){
	if ($(window).scrollTop() >= 2000 && $(window).width() >=900){
			
			$('#dad').stop().animate({
				paddingLeft: '257px'
				}, 800);
				$('#P4').fadeIn();
				}
			});	
			
			////////Dan bars
			$(window).bind("scroll", function(){
	if ($(window).scrollTop() >= 2000 && $(window).width() >=900){
			
			$('#cr').stop().animate({
				paddingLeft: '295px'
				}, 500);
				$('#D1').fadeIn();
				}
			
			
			});	
			
			$(window).bind("scroll", function(){
	if ($(window).scrollTop() >= 2000 && $(window).width() >=900){
			
			$('#qos').stop().animate({
				paddingLeft: '264px'
				}, 600);
				$('#D2').fadeIn();
				}
			});	
		
		$('span').hide();
		
		
	//////back to top 
	$('#backTop').hide();
	$(window).bind("scroll", function(){
	
	if ($(window).scrollTop() >= 3500 && $(window).width() >=900){
			
			$('#backTop').fadeIn();
			$('#backTop').click(function(e){
		$('#blackBox').animate({
			paddingLeft: '0%'
			}, 0);
				$('#One').fadeIn();
				$('#Two').fadeIn();
				$('#Three').fadeIn();
				$('#Four').fadeIn();
				$('#Five').fadeIn();
				$('#Six').fadeIn();
				
				
				
				
				
				$('#thebonds').fadeOut();
			
		});
		}
	});
	
	
	
	
	/*
	*HIDDEN ARROWS
	*/
	$('#upSG').hide();
	$('#upSGR').hide();
	$('#upSK').hide();
	$('#upSR').hide();
	$('#upSV').hide();
	
	$('#upGG').hide();
	$('#upGGR').hide();
	$('#upGK').hide();
	$('#upGR').hide();
	$('#upGV').hide();
	
	$('#upTG').hide();
	$('#upTGR').hide();
	$('#upTK').hide();
	$('#upTR').hide();
	$('#upTV').hide();
	
	$('#upRG').hide();
	$('#upRGR').hide();
	$('#upRK').hide();
	$('#upRR').hide();
	$('#upRV').hide();
	
	$('#upPG').hide();
	$('#upPGR').hide();
	$('#upPK').hide();
	$('#upPR').hide();
	$('#upPV').hide();
	
	$('#upDG').hide();
	$('#upDGR').hide();
	$('#upDK').hide();
	$('#upDR').hide();
	$('#upDV').hide();
	
	//OVERALL HIDE
	$('#Soverall').hide();
	$('#Goverall').hide();
	$('#Toverall').hide();
	$('#Roverall').hide();
	$('#Poverall').hide();
	$('#Doverall').hide();
	
	});