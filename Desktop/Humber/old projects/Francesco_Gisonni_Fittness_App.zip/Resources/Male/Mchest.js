

views = [
	{backgroundImage:'/box.png', borderRadius:10,  top:10, left: 10, nextPage: '/workout.js', background: 'pImage.jpg', title:'Workout' , myScrollableImages:['boxEx.png', 'boxEx.png'],theSteps: ['Step 1: Lay back on yoga ball.', 'Step 2: Incline up']},
	{backgroundImage:'/box.png', borderRadius:10,  top:10, left: 253, nextPage: '/workout.js', background: 'pImage.jpg', title:'Workout', myScrollableImages:['boxEx.png', 'boxEx.png'], theSteps: ['Step1: This would be a step', 'Step2:This would be another step.' ]},
	{backgroundImage:'/box.png', borderRadius:10, top:10, left: 498, nextPage: '/workout.js', background: 'pImage.jpg' , title:'Workout', myScrollableImages:['boxEx.png', 'boxEx.png'], theSteps: ['Step1: This would be a step', 'Step2:This would be another step.' ]},
	{backgroundImage:'/box.png', borderRadius:10, top:245, left: 10, nextPage: '/workout.js', background: 'pImage.jpg', title:'Workout' , myScrollableImages:['boxEx.png', 'boxEx.png'], theSteps: ['Step1: This would be a step', 'Step2:This would be another step.' ]},
	{backgroundImage:'/box.png', borderRadius:10, top:245, left: 253, nextPage: '/workout.js', background: 'pImage.jpg' , title:'Workout', myScrollableImages:['boxEx.png', 'boxEx.png'], theSteps: ['Step1: This would be a step', 'Step2:This would be another step.' ]},
	{backgroundImage:'/box.png', borderRadius:10, top:245, left: 498, nextPage: '/workout.js', background: 'pImage.jpg' , title:'Workout', myScrollableImages:['boxEx.png', 'boxEx.png'], theSteps: ['Step1: This would be a step', 'Step2:This would be another step.' ]},
	{backgroundImage:'/box.png', borderRadius:10,  top:475	, left: 10, nextPage: '/workout.js', background: 'pImage.jpg', title:'Workout', myScrollableImages:['boxEx.png', 'boxEx.png'], theSteps: ['Step1: This would be a step', 'Step2:This would be another step.' ] },

]


var scrollView = Titanium.UI.createScrollView({ contentWidth: false, contentHeight:'auto', top:0, showVerticalScrollIndicator:true, });

for (var i = 0; i < views.length; i++){

var view = Ti.UI.createButton ({
	backgroundImage: views[i].backgroundImage,
	width: 261,
	height: 251,
	left: views[i].left,
	top: views[i].top,
	right: 15,
	
	//urlPage: views[i].nextPage,
	//workOutImage: views[i].background,
	//titlePage: views[i].title,*/
	grabThis:views[i]
});

scrollView.add(view); 
view.addEventListener('click', openThisWindow);
}
var win = Ti.UI.createWindow();

var secondWin = Titanium.UI.currentWindow;
secondWin.add(scrollView);

var workoutNav = Ti.UI.iPhone.createNavigationGroup({
		window: secondWin
	});
win.add(workoutNav);	

function openThisWindow(e){
	var openThisWindow = Ti.UI.createWindow({
		url: e.source.grabThis.nextPage,
		backgroundImage: e.source.grabThis.background,
		title: e.source.grabThis.title,
		opacity: 0,
		barColor: '#4c4c4c',
		animatedCenterPoint: 'center',
		data: e.source.grabThis
	});
	openThisWindow.open();
	openThisWindow.animate({
		opacity: 1
});
	
}
secondWin.orientationModes =  [
		Ti.UI.PORTRAIT,
		Ti.UI.UPSIDE_PORTRAIT,
		]