<?php
// Database connection constants
define("DATABASE_HOST", "mysql.parafx.com");
define("DATABASE_USERNAME", "gsnf0005");
define("DATABASE_PASSWORD", "Loop4worm" );
define("DATABASE_NAME", "gsnf0005" );
?>