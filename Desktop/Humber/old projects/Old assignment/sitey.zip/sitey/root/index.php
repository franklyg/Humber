<?php 
	include ('includes/header.php');
?>


<div class="content fc">

    <div class="one_col fl">
    	<h2>LINX Club Goes Big 01/10/2012</h2>
        <img src="images/header_img.jpg" />
        <p class="details">Last Nights Club Preview with DJ Derek B</p>
        
        <div class="clr"></div>
        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged</p>
        
    </div>
    
    <div class="two_col fl">
    <h2>Recent Blog Posts</h2>
    
    
 <div class="events">
    	<img class="fl" src="images/event.png">
    		<h3 class="fl"> EVENT AT THE CLUB</h3>
    			<a href="fr">Click Here For More Info</a>
</div>
	<div class="clr"></div>
<div class="events">
		<img class="fl" src="images/event1.png">
			<h3 class="fl"> EVENT AT THE CLUB</h3>
				<a href="fr">Click Here For More Info</a>
</div>
	<div class="clr"></div>

<div class="events">
		<img class="fl" src="images/event2.png">
			<h3 class="fl"> EVENT AT THE CLUB</h3>
				<a href="fr">Click Here For More Info</a>
</div>
	<div class="clr"></div>
<div class="events">
		<img class="fl" src="images/event3.png">
				<h3 class="fl"> EVENT AT THE CLUB</h3>
					<a href="fr">Click Here For More Info</a>
</div>
	<div class="clr"></div>

<div class="events">
			<img class="fl" src="images/event4.png">
				<h3 class="fl"> EVENT AT THE CLUB</h3>
					<a href="fr">Click Here For More Info</a>
</div>
	<div class="clr"></div>
<div class="events">
		<img class="fl" src="images/Untitled-5.png">
				<h3 class="fl"> EVENT AT THE CLUB</h3>
					<a href="fr">Click Here For More Info</a>
</div>
</div>
    
</div><!--content-->
</body>
</html>
