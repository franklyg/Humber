<?php
	include ('includes/header.php')
 ?>


<div class="content fc">

    <div class="one_col fl">
    	<h2>LINX Club Goes Big 01/10/2012</h2>
        <img src="images/about.jpg" />
        <p class="details">Photo Cred: DJ Derry B</p>
        <div class="clr"></div>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec eu viverra magna. In hac habitasse platea dictumst. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Aenean et elit massa, eget eleifend nulla. Ut quis ornare magna. Duis at condimentum magna. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Praesent ut sapien lorem. Nam adipiscing molestie metus, non rutrum turpis sagittis quis. Nam accumsan, purus a vestibulum commodo, lectus massa ultrices mi, vel blandit lacus tellus a velit. Donec at erat a odio imperdiet scelerisque eu posuere nibh. </p>
        <img src="images/about_us.jpg" />
         <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec eu viverra magna. In hac habitasse platea dictumst. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Aenean et elit massa, eget eleifend nulla. Ut quis ornare magna. Duis at condimentum magna. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. </p>
    </div>
    
    <div class="two_col fl">
    <h2>Recent Event Posts</h2>
    	<div class="events">
        <img  class="fl" src="images/event.png"/> <h3 class="fl"> EVENT AT THE CLUB</h3><a href="fr">Click Here For More Info</a>
        </div>
        <div class="clr"></div>
        <div class="events">
        <img  class="fl" src="images/event1.png"/> <h3 class="fl"> EVENT AT THE CLUB</h3><a href="fr">Click Here For More Info</a>
        </div
        ><div class="clr"></div>
      <div class="events">
        <img  class="fl" src="images/event2.png"/> <h3 class="fl"> EVENT AT THE CLUB</h3><a href="fr">Click Here For More Info</a>
        </div>
        <div class="clr"></div>
        <div class="events">
        <img  class="fl" src="images/event3.png"/> <h3 class="fl"> EVENT AT THE CLUB</h3><a href="fr">Click Here For More Info</a>
        </div>
         <div class="clr"></div>>
        <div class="events">
        <img  class="fl" src="images/event4.png"/> <h3 class="fl"> EVENT AT THE CLUB</h3><a href="fr">Click Here For More Info</a>
        </div>
        <div class="clr"></div>
        <div class="events">
        <img  class="fl" src="images/Untitled-5.png"/> <h3 class="fl"> EVENT AT THE CLUB</h3><a href="fr">Click Here For More Info</a>
        </div>
 
    </div>
    
</div><!--content-->
</body>
</html>
