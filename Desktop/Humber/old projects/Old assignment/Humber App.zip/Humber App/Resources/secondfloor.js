
var tabGroup = Ti.UI.createTabGroup();
 
var win = Ti.UI.createWindow({
    backgroundColor: '#FFF',
    title:'Classes',
   tabBarHidden: true,
   navBarHidden: true
    
    
    
});
 
 
var tab = Ti.UI.createTab({
    title:"1st Floor Classrooms",
    window: win,
    
});
 
tabGroup.addTab(tab);
tabGroup.open({transition: Ti.UI.iPhone.AnimationStyle.FLIP_FROM_RIGHT});
var floors = [
	{title: 'B201', header: 'B', test: 'mapB2.js'},
	{title: 'B202', test: 'mapB2.js'},
	{title: 'B203' , test: 'mapB2.js'},
	{title: 'B204', test: 'mapB2.js'},
	{title: 'B205 ', test: 'mapB2.js'},
	{title: 'B206', test: 'mapB2.js'},
	{title: 'B207', test: 'mapB2.js'},
	{title: 'B208', test: 'mapB2.js'},
	{title: 'B211', test: 'mapB2.js'},
	{title: 'B212', test: 'mapB2.js'},
	{title: 'B213 ', test: 'mapB2.js'},
	{title: 'B214 ', test: 'mapB2.js'},
	{title: 'B215', test: 'mapB2.js'},
	{title: 'B216', test: 'mapB2.js'},
	{title: 'C200', header: 'C', test: 'map2.js'},
	
	{title: 'D202' ,header: 'D', test: 'mapD2.js'},
	{title: 'D203',test: 'mapD2.js' },
	
	{title: 'D206',test: 'mapD2.js'},
	{title: 'D207,',test: 'mapD2.js'},
	{title: 'D212',test: 'mapD2.js'},
	{title: 'D216',test: 'mapD2.js'},
	{title: 'D218',test: 'mapD2.js'},
	{title: 'D219',test: 'mapD2.js'},
	{title: 'D221',test: 'mapD2.js'},
	{title: 'D222',test: 'mapD2.js'},
	{title: 'D225',test: 'mapD2.js'},
	{title: 'D234',test: 'mapD2.js'},
	{title: 'D235',test: 'mapD2.js'},
	{title: 'D237',test: 'mapD2.js'},
	{title: 'D239',test: 'mapD2.js'},
	///////////////
	{title: 'D241',test: 'mapD2.js'},
	{title: 'D242',test: 'mapD2.js'},
	{title: 'E230', header: 'E',test: 'mapE2.js'},
	{title: 'E231',test: 'mapE2.js'},
	{ title: 'F202', header: 'F',test: 'mapF2.js' },
	{ title: 'F205',test: 'mapF2.js' } ,
	{ title: 'F212' ,test: 'mapF2.js'} ,
	{ title: 'F220',test: 'mapF2.js'} ,
	{ title: 'F223',test: 'mapF2.js' } ,
	{ title: 'F229',test: 'mapF2.js' } ,
	{ title: 'F231' ,test: 'mapF2.js'} ,
	{ title: 'F232',test: 'mapF2.js'} ,
	{ title: 'F233',test: 'mapF2.js' } ,
	{ title: 'F235' ,test: 'mapF2.js'} ,
	{ title: 'F236',test: 'mapF2.js' } ,
	{ title: 'GH225', header: 'GH' ,test: 'mapGH2.js'} ,
	{ title: 'H207' , header: 'H',test: 'mapH2.js'} ,
	{ title: 'H211',test: 'mapH2.js' } ,
	{ title: 'L212' , header: 'L',test: 'mapL2.js'}, 
	{ title: 'L213',test: 'mapL2.js' } ,
	{ title: 'WD211' , header: 'WD' ,test: 'mapWD.js' } 

];
var table = Ti.UI.createTableView({
	data: floors,
	top: 44,
	showVerticalScrollIndicator:true,
	
	
	
	
});
table.addEventListener('click', function(e)
{
	if (e.rowData.test)
	{
		var win = null;

			win = Titanium.UI.createWindow({
				url:e.rowData.test,
				title:e.rowData.title,
				zIndex: 5
				

			});
		win.open();
	}
	
	win.open();
});
var backBtn = Ti.UI.createButton({
	image:'back.png',
	backgroundDisabledColor: true,
	backgroundImage: true,
	borderRadius: false,
	top: 3,
	left: 3,
	zIndex: 5
});
var nav = Ti.UI.createImageView ({
	image: 'bg-(2).png',
	top:0
});
backBtn.addEventListener('click', function(e){
	Ti.include('classrooms.js')
});
var title = Ti.UI.createLabel({
	text: 'Second Floor',
	color: 'white',
	top: 8,
	zIndex: 4,
	 font:{
                fontWeight:'bold',
                fontSize:20
            }
});
win.add(title);
win.add(table)
win.open();
win.add(nav);
win.add(backBtn)