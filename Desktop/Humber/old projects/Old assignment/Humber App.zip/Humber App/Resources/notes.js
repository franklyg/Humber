var tabGroup = Ti.UI.createTabGroup();
 
var win = Ti.UI.createWindow({
    backgroundImage: 'bg-(1).jpg',
    title:'Humber App',
    tabBarHidden:true,
    navBarHidden: true,
    barImage: 'bg-(2).png'
    
});
 
 
var tab = Ti.UI.createTab({
    title:"Doesn't matter",
    window: win
});

var backBtn = Ti.UI.createButton({
	image:'back.png',
	backgroundDisabledColor: true,
	backgroundImage: true,
	borderRadius: false,
	top: 3,
	left: 3,
	zIndex: 5
});
var nav = Ti.UI.createImageView ({
	image: 'bg-(2).png',
	top:0
});


backBtn.addEventListener("click", function(e){
	Ti.include('app.js')
	Ti.UI.createImageView({
		image: 'clicked.png',
	});
	// Save textarea content in file
    var file = Ti.Filesystem.getFile(Ti.Filesystem.applicationDataDirectory, "foo.txt");
    file.write(ta1.value);
 
    // Unfocus textarea to hide keyboard
    ta1.blur();
    return file;
}); 


var ta1 = Titanium.UI.createTextArea({
    value: '',
    height:480,
    width:330,
    top:44,
    font:{fontSize:20,fontFamily:'Marker Felt', fontWeight:'bold'},
    color:'#888',
    backgroundColor: '#CCCCCC',
    textAlign:'left',
    appearance:Titanium.UI.KEYBOARD_APPEARANCE_ALERT,   
    keyboardType:Titanium.UI.KEYBOARD_DEFAULT,
    returnKeyType:Titanium.UI.RETURNKEY_DEFAULT,
    borderWidth:2,
    borderColor:'#bbb',
    borderRadius:5,
    editable: true,
   
});

win.add(ta1);


	
		ta1.addEventListener('focus', function(e){
  		 var forLater = ta1.value;
		Ti.App.Properties.setString('forLater', forLater);
		Ti.API.info('The value of the givenName property is: ' + Ti.App.Properties.getString( "forLater"));
		return forLater;
	
    });
ta1.addEventListener('blur', function(e){
  		 var forLater = ta1.value;
		Ti.App.Properties.setString('forLater', forLater);
      	Ti.API.info('The value of the givenName property is: ' + Ti.App.Properties.getString( "forLater"));
      	return forLater;
      	
});

ta1.addEventListener('change', function(e){
  		 var forLater = ta1.value;
		Ti.App.Properties.setString('forLater', forLater);
      	Ti.API.info('The value of the givenName property is: ' + Ti.App.Properties.getString( "forLater"));
      	return forLater;
      	

});
	
 


function loadTextFromFile() {
    var file = Ti.Filesystem.getFile(Ti.Filesystem.applicationDataDirectory, "foo.txt");
    return file.exists() ? file.read().text : "";
}



/*ta1.addEventListener('change', function(e){
		var forLater = ta1.value;
		Ti.App.Properties.setString('forLater', ta1.value);
		Ti.API.info('The value of the givenName property is: ' + Ti.App.Properties.getString( "forLater"));
		
  });*/
var title = Ti.UI.createLabel({
	text: 'Notes',
	color: 'white',
	top: 8,
	zIndex: 4,
	 font:{
                fontWeight:'bold',
                fontSize:20
            }
});
win.add(title)
win.add(backBtn);
win.add(nav);
tabGroup.addTab(tab);
tabGroup.open({transition: Ti.UI.iPhone.AnimationStyle.FLIP_FROM_RIGHT});