var tabGroup = Ti.UI.createTabGroup();
 
var win = Ti.UI.createWindow({
    backgroundImage: 'bg-(1).jpg',
    title:'Humber App',
    tabBarHidden:true,
    navBarHidden: true,
    barImage: 'bg-(2).png'
    
});
var title = Ti.UI.createLabel({
	text: 'Community',
	color: 'white',
	top: 8,
	zIndex: 4,
	 font:{
                fontWeight:'bold',
                fontSize:20
            }
});
win.add(title);
 
var tab = Ti.UI.createTab({
    title:"Doesn't matter",
    window: win
});

var backBtn = Ti.UI.createButton({
	image:'back.png',
	backgroundDisabledColor: true,
	backgroundImage: true,
	borderRadius: false,
	top: 3,
	left: 3,
	zIndex: 5
});
var nav = Ti.UI.createImageView ({
	image: 'bg-(2).png',
	top:0
});
backBtn.addEventListener('click', function(e){
	Ti.include('app.js');
	
}); 
var fb = Ti.UI.createView ({
	backgroundColor: '#3b5999',
	width: 320,
	height: 240,
	top: 44
});
var tw = Ti.UI.createView ({
	backgroundColor: '#94e4e8',
	width: 320,
	height: 240,
	bottom: 0
});
var fbBtn = Ti.UI.createButton({
	image: 'like.png',
	backgroundDisabled: true,
	backgroundImage: true,
	borderRadius: false,
	top: 150,
	
}); 
var twitBtn = Ti.UI.createButton({
	image: 'twbtn.png',
	backgroundDisabled: true,
	backgroundImage: true,
	borderRadius: false,
	top: 360
	
}); 
var fbImg = Ti.UI.createImageView ({
	image: 'facebook-logo.png',
	top: 60,
	zIndex: 5
});
var twImg = Ti.UI.createImageView ({
	image: 'tiwt.png',
	top: 240,
	zIndex: 5
});
fbBtn.addEventListener('click', function(e){
	Ti.include('facebook.js');
	
});
twitBtn.addEventListener('click', function(e){
	Ti.include('twitter.js');
	
})
win.add(fbImg)
win.add(twImg)
win.add(fb);
win.add(tw);
win.add(fbBtn)
win.add(twitBtn)
win.add(backBtn);
win.add(nav);

tabGroup.addTab(tab);
tabGroup.open({transition: Ti.UI.iPhone.AnimationStyle.FLIP_FROM_RIGHT});