var tabGroup = Ti.UI.createTabGroup();
 
var win = Ti.UI.createWindow({
    backgroundColor: '#FFF',
    title:'Classrooms',
    tabBarHidden:true,
    backButtonTitle: true,
    navBarHidden: true,
  
   
});
 
 
var tab = Ti.UI.createTab({
    title:"Doesn't matter",
    window: win,
    
});
 
tabGroup.addTab(tab);
tabGroup.open({transition: Titanium.UI.iPhone.AnimationStyle.FLIP_FROM_RIGHT
	});





var rows =  [
	{title: "1st Floor" ,hasChild: true, test: 'firstfloor.js'},
	{title: "2nd Floor" ,hasChild: true, test: 'secondfloor.js'},
	{title: "3rd Floor" ,hasChild: true, test: 'thirdfloor.js'},
	{title: "4th Floor" ,hasChild: true, test: 'fourthfloor.js'},
	

];


var table = Ti.UI.createTableView({
	data: rows,
	top: 44,
	scrollable: false,
	
	
	
	
});
table.addEventListener('click', function(e)
{
	if (e.rowData.test)
	{
		var win = null;

			win = Titanium.UI.createWindow({
				url:e.rowData.test,
				title:e.rowData.title,
				zIndex: 5
				

			});
		win.open();
	}
	
	win.open();
});
var backBtn = Ti.UI.createButton({
	image:'back.png',
	backgroundDisabledColor: true,
	backgroundImage: true,
	borderRadius: false,
	top: 3,
	left: 3,
	zIndex: 5
});
var nav = Ti.UI.createImageView ({
	image: 'bg-(2).png',
	top:0,
	
	label: 'hello'
});
backBtn.addEventListener('click', function(e){
	Ti.include('app.js')
	transition:Titanium.UI.iPhone.AnimationStyle.FLIP_FROM_RIGHT
});
var title = Ti.UI.createLabel({
	text: 'Classrooms',
	color: 'white',
	top: 8,
	zIndex: 4,
	 font:{
                fontWeight:'bold',
                fontSize:20
            }
});
win.add(title);

win.add(table);
win.add(backBtn);
win.add(nav);

