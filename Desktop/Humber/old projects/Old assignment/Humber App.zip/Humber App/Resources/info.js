var tabGroup = Ti.UI.createTabGroup();
 
var win = Ti.UI.createWindow({
    backgroundColor: '#3f6c8e',
    title:'Humber App',
    tabBarHidden:true,
    navBarHidden: true,
    barImage: '#3f6c8e',
    
    
    
});
 
 
var tab = Ti.UI.createTab({
    title:"Doesn't matter",
    window: win
});

var backBtn = Ti.UI.createButton({
	image:'back.png',
	backgroundDisabledColor: true,
	backgroundImage: true,
	borderRadius: false,
	top: 3,
	left: 3,
	zIndex: 5
});
var nav = Ti.UI.createImageView ({
	image: 'bg-(2).png',
	top:0
});
backBtn.addEventListener('click', function(e){
	Ti.include('events.js')
}); 

var view = Ti.UI.createView ({
	
	width: 300,
	height: 125,
	backgroundColor: 'white',
	borderRadius: 10,
	shadow: 'black',
	top: 80,
	
});

var view2 = Ti.UI.createView ({
	
	width: 300,
	height: 45,
	backgroundColor: 'white',
	borderRadius: 10,
	shadow: 'black',
	bottom: 70
});
var  view3 =  Ti.UI.createView ({
		width: 300,
	height: 90,
	backgroundColor: 'white',
	borderRadius: 10,
	shadow: 'black',
	bottom: 140
});

var label = Ti.UI.createLabel ({
	text: 'Where: LinX Pub' ,
	color: 'black',
	padding: 5,
	textAlign: 'center',
	
	
});
var label2 = Ti.UI.createLabel ({
	text: "Time: 6pm - 2am",
	bottom: 20
	
});

var label3 = Ti.UI.createLabel ({
	text: "Desripction:",
	top: 0,
	left: 5,
	width: 285
});
var label4 = Ti.UI.createLabel ({
	text: "Attention Moebros! Let's get this party started!!! Friday, November 29th, 2012 we will be hosting our second annual Movember Party. Be there!  "
	, top: 23,
	font: {fontSize:14},
	left: 5,
	width: 285
});
var label5 = Ti.UI.createLabel ({
	text: 'Friday, November 29th, 2012'	,
	top: 10

});
var title = Ti.UI.createLabel({
	text: 'Party Info',
	color: 'white',
	top: 8,
	zIndex: 4,
	 font:{
                fontWeight:'bold',
                fontSize:20
            }
});
win.add(title);

view3.add(label5);
win.add(view2);
view.add(label3);
view.add(label4);
win.add(view3);
view3.add(label2);
win.add(view);
view2.add(label)
win.add(backBtn);
win.add(nav);
tabGroup.addTab(tab);
tabGroup.open({transition: Ti.UI.iPhone.AnimationStyle.FLIP_FROM_RIGHT});