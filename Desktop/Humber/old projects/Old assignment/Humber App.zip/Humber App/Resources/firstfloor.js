
var tabGroup = Ti.UI.createTabGroup();
 
var win = Ti.UI.createWindow({
    backgroundColor: '#FFF',
    title:'Classes',
   tabBarHidden: true,
   navBarHidden: true
    
    
    
});
 
 
var tab = Ti.UI.createTab({
    title:"1st Floor Classrooms",
    window: win,
    
});
 
tabGroup.addTab(tab);
tabGroup.open({transition: Ti.UI.iPhone.AnimationStyle.FLIP_FROM_RIGHT});
var floors = [
	{title: 'B105', header: 'B', test: 'mapB1.js'},
	{title: 'B106' , test: 'mapB1.js'},
	{title: 'C109', header: 'C' , test: 'map.js'},
	{title: 'C110', test: 'map.js'},
	{title: 'CA102', header: 'CA' , test: 'mapCA.js'},
	{title: 'CA107', test: 'mapCA.js'},
	{title: 'CA108', test: 'mapCA.js'},
	{title: 'CA109', test: 'mapCA.js'},
	{title: 'CA115', test: 'mapCA.js'},
	{title: 'CA123', test: 'mapCA.js'},
	{title: 'CA127', test: 'mapCA.js'},
	{title: 'CA130', test: 'mapCA.js'},
	{title: 'CA132', test: 'mapCA.js'},
	{title: 'CA133', test: 'mapCA.js'},
	{title: 'CA134', test: 'mapCA.js'},
	{title: 'CB104', header: 'CB', test: 'mapCB.js'},
	{title: 'E135' ,header: 'E', test: 'mapE1.js'},
	{title: 'F102', header: 'F', test: 'mapF1.js'},
	{title: 'F113', test: 'mapF1.js'},
	{title: 'F114', test: 'mapF1.js'},
	{title: 'F115', test: 'mapF1.js'},
	{title: 'F130', test: 'mapF1.js'},
	{title: 'F132', test: 'mapF1.js'},
	{title: 'F135', test: 'mapF1.js'},
	{title: 'GH111', header: 'GH', test: 'mapGH1.js'},
	{title: 'GH117', test: 'mapGH1.js'},
	{title: 'GH121', test: 'mapGH1.js'},
	{title: 'GH122', test: 'mapGH1.js'},
	{title: 'GH123', test: 'mapGH1.js'},
	{title: 'GH124', test: 'mapGH1.js'},
	{title: 'GH125', test: 'mapGH1.js'},
	{title: 'GH126', test: 'mapGH1.js'},
	///////////////
	
];
var table = Ti.UI.createTableView({
	data: floors,
	top: 44,
	showVerticalScrollIndicator:true,
	
	
	
	
});
table.addEventListener('click', function(e)
{
	if (e.rowData.test)
	{
		var win = null;

			win = Titanium.UI.createWindow({
				url:e.rowData.test,
				title:e.rowData.title,
				zIndex: 5
				

			});
		win.open();
	}
	
	win.open();
});
var backBtn = Ti.UI.createButton({
	image:'back.png',
	backgroundDisabledColor: true,
	backgroundImage: true,
	borderRadius: false,
	top: 3,
	left: 3,
	zIndex: 5
});
var nav = Ti.UI.createImageView ({
	image: 'bg-(2).png',
	top:0
});
backBtn.addEventListener('click', function(e){
	Ti.include('classrooms.js')
});
var title = Ti.UI.createLabel({
	text: 'First Floor',
	color: 'white',
	top: 8,
	zIndex: 4,
	 font:{
                fontWeight:'bold',
                fontSize:20
            }
});
win.add(title);

win.add(table)
win.open();
win.add(nav);
win.add(backBtn)
