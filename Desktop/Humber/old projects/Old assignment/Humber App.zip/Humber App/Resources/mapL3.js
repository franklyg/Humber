var tabGroup = Ti.UI.createTabGroup();
 
var win = Ti.UI.createWindow({
    backgroundColor: '#FFF',
    title:'Classrooms',
    tabBarHidden:true,
    backButtonTitle: true,
    navBarHidden: true,
  
   
});
 
 
var tab = Ti.UI.createTab({
    title:"Doesn't matter",
    window: win,
    
});
 
tabGroup.addTab(tab);
tabGroup.open({transition: Titanium.UI.iPhone.AnimationStyle.FLIP_FROM_RIGHT
	});

var map = Ti.UI.createImageView ({
	
	image: 'mapLand.jpg'
})


var backBtn = Ti.UI.createButton({
	image:'back.png',
	backgroundDisabledColor: true,
	backgroundImage: true,
	borderRadius: false,
	top: 3,
	left: 3,
	zIndex: 5
});
var nav = Ti.UI.createImageView ({
	image: 'bg-(2).png',
	top:0,
	zIndex: 3,
	
	label: 'hello'
});
backBtn.addEventListener('click', function(e){
	Ti.include('thirdfloor.js')
	transition:Titanium.UI.iPhone.AnimationStyle.FLIP_FROM_RIGHT
});

map.addEventListener('pinch', function(e) {
    var t = Ti.UI.create2DMatrix().scale(e.scale);
    map.transform = t;
});

var pin = Ti.UI.createImageView ({
	
	image: 't.png',
		zIndex: 2,
		top: 0,
		left: 148, 
		
		
});

pin.animate({
	top:258, 
	
	duration:1500, 
	curve:Titanium.UI.ANIMATION_CURVE_EASE_IN,
	ease: 500
});
var title = Ti.UI.createLabel({
	text: 'Hello',
	color: 'white',
	top: 0
});
win.add(title);
win.add(pin);
win.add(map);
win.add(backBtn);
win.add(nav);
