/*********************************************
 * HUMBER APP ALL RIGHTS RESERVED 
 * BY FRANCESCO GISONNI & STEPHAN PERALTA
 * *******************************************/



var tabGroup = Ti.UI.createTabGroup();
 
var win = Ti.UI.createWindow({
    backgroundColor: '#3f6c8e',
    title:'Humber Guide',
    tabBarHidden:true,
    barImage: 'bg-(2).png'
    
});
 
 
var tab = Ti.UI.createTab({
    title:"Doesn't matter",
    window: win
});

tabGroup.addTab(tab);
tabGroup.open();
///////////////////////BUTTONS/////////////////////
var btn = Ti.UI.createButton({
	image: 'humberImages/classrooms.png',
	left: 20,
	top: 20,
	backgroundDisabledColor: true,
	backgroundImage: true,
	borderRadius: false,
});
var btn2 = Ti.UI.createButton({
	image: 'humberImages/services.png',
	top: 20,
	right: 20,
	backgroundDisabledColor: true,
	backgroundImage: true,
	borderRadius: false,
});
var btn3 = Ti.UI.createButton ({
	image: 'humberImages/events.png',
	left: 20,	
	top: 150,
	backgroundDisabledColor: true,
	backgroundImage: true,
	borderRadius: false,
});
var btn4 = Ti.UI.createButton ({
	image: 'humberImages/updates.png',
	right: 20 ,
	top: 150,
	backgroundDisabledColor: true,
	backgroundImage: true,
	borderRadius: false,
});
var btn5 = Ti.UI.createButton ({
	image: 'humberImages/community.png',
	left: 20,
	top: 290,
	backgroundDisabledColor: true,
	backgroundImage: true,
	borderRadius: false,
});

var btn6 = Ti.UI.createButton ({
	image: 'humberImages/notes.png',
	right: 20,
	top: 290,
	backgroundDisabledColor: true,
	backgroundImage: true,
	borderRadius: false,
});


////////////BUTTOON EVENT LISTENERS
btn.addEventListener('click', function(e){
	Ti.include('classrooms.js')
	
});
	


btn2.addEventListener('click', function(e){
	Ti.include('services.js')
});
btn3.addEventListener ('click', function (e){
	Ti.include('events.js')
});
btn4.addEventListener('click', function (e){
	Ti.include('updates.js')
});
btn5.addEventListener ( 'click', function(e){
	Ti.include('community.js')
})
btn6.addEventListener('click', function (e){
	Ti.include('notes.js')
	
});



win.add(btn);
win.add(btn2);
win.add(btn3);
win.add(btn4);
win.add(btn5);
win.add(btn6);
