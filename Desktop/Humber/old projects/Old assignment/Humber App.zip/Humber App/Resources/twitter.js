var tabGroup = Ti.UI.createTabGroup();
 
var win = Ti.UI.createWindow({
    backgroundImage: 'bg-(1).jpg',
    title:'Humber App',
    tabBarHidden:true,
    navBarHidden: true,
    barImage: 'bg-(2).png'
    
});
var title = Ti.UI.createLabel({
	text: 'Twitter',
	color: 'white',
	top: 8,
	zIndex: 4,
	 font:{
                fontWeight:'bold',
                fontSize:20
            }
});
win.add(title);
 
var tab = Ti.UI.createTab({
    title:"Doesn't matter",
    window: win
});

var backBtn = Ti.UI.createButton({
	image:'back.png',
	backgroundDisabledColor: true,
	backgroundImage: true,
	borderRadius: false,
	top: 3,
	left: 3,
	zIndex: 5
});
var nav = Ti.UI.createImageView ({
	image: 'bg-(2).png',
	top:0
});
backBtn.addEventListener('click', function(e){
	Ti.include('community.js');
	
}); 

var webview = Titanium.UI.createWebView({url:'https://twitter.com/humbercollege'});

win.add(webview);
win.add(backBtn);
win.add(nav);

tabGroup.addTab(tab);
tabGroup.open({transition: Ti.UI.iPhone.AnimationStyle.FLIP_FROM_RIGHT});