
var tabGroup = Ti.UI.createTabGroup();
 
var win = Ti.UI.createWindow({
    backgroundColor: '#FFF',
    title:'Classes',
   tabBarHidden: true,
   navBarHidden: true
    
    
    
});
 
 
var tab = Ti.UI.createTab({
    title:"1st Floor Classrooms",
    window: win,
    
});
 
tabGroup.addTab(tab);
tabGroup.open();
var floors = [
	{title: 'x11'},
	{title: 'x11'},
	{title: 'x11'},
	{title: 'x11'},
	{title: 'x11'},
	{title: 'x11'},
	{title: 'x11'},
];
var table = Ti.UI.createTableView({
	data: floors,
	top: 49
	
});
var backBtn = Ti.UI.createButton({
	image:'back.png',
	backgroundDisabledColor: true,
	backgroundImage: true,
	borderRadius: false,
	top: 7,
	left: 0,
	zIndex: 5
});
var nav = Ti.UI.createImageView ({
	image: 'bg-(2).png',
	top:0
});
backBtn.addEventListener('click', function(e){
	Ti.include('classrooms.js')
});
win.add(table)
win.open();
win.add(nav);
win.add(backBtn)