
var tabGroup = Ti.UI.createTabGroup();
 
var win = Ti.UI.createWindow({
    backgroundColor: '#FFF',
    title:'Services',
   tabBarHidden: true,
   navBarHidden: true
   });
 
 
var tab = Ti.UI.createTab({
    title:"1st Floor Classrooms",
    window: win,
    
});
//BACK BUTTON////////////////////
var backBtn = Ti.UI.createButton({
	image:'back.png',
	backgroundDisabledColor: true,
	backgroundImage: true,
	borderRadius: false,
	top: 5,
	left: 3,
	zIndex: 5
});
var nav = Ti.UI.createImageView ({
	image: 'bg-(2).png',
	width: 320,
	top: 0
});
backBtn.addEventListener('click', function(e){
	Ti.include('app.js')
}); 
/////list Tings/////////////
var service = [
	{title: 'HSF', header: 'Recreational', hasChild: true, test: 'mapH.js' },
	{title: 'Library', hasChild: true, test: 'mapH.js'},
	{title: 'Registration', hasChild: true, test: 'mapH.js'},
	{title: 'Book Store', hasChild: true, test: 'mapH.js'},
	{title: 'Cafeteria', hasChild: true, test: 'mapH.js'},
	{title: 'Gourmet Express', hasChild: true, test: 'mapH.js'},
	{title: 'Gym', hasChild: true, test: 'mapH.js'},
	{title: 'Residence', hasChild: true, test: 'mapH.js'},
	{title: 'Media Department' , header: 'Education', hasChild: true, test: 'mapH.js'},
	{title: 'Health Department', hasChild: true, test: 'mapH.js'},
	{title: 'Culinary Department', hasChild: true, test: 'mapH.js'},
	{title: 'Liberal Arts and Sceince Office', hasChild: true, test: 'mapH.js'},
	{title: 'English Centre', hasChild: true, test: 'mapH.js'},
	{title: 'Tutoring Office', hasChild: true, test: 'mapH.js'},
	
	
	
	
	
	
];
var table = Ti.UI.createTableView ({
	data: service,
	top: 44
});
table.addEventListener('click', function(e)
{
	if (e.rowData.test)
	{
		var win = null;

			win = Titanium.UI.createWindow({
				url:e.rowData.test,
				title:e.rowData.title,
				zIndex: 5
				

			});
		win.open();
	}
	
	win.open();
});
var title = Ti.UI.createLabel({
	text: 'Services',
	color: 'white',
	top: 8,
	zIndex: 4,
	 font:{
                fontWeight:'bold',
                fontSize:20
            }
});
win.add(title);
win.add(table);
win.add(backBtn);
win.add(nav);
tabGroup.addTab(tab);
tabGroup.open({transition: Ti.UI.iPhone.AnimationStyle.FLIP_FROM_RIGHT});