var tabGroup = Ti.UI.createTabGroup();
 
var win = Ti.UI.createWindow({
    backgroundImage: '#3f6c8e',
    title:'Humber App',
    tabBarHidden:true,
    navBarHidden: true,
    barImage: 'bg-(2).png'
    
});
 
 
var tab = Ti.UI.createTab({
    title:"Doesn't matter",
    window: win
});

var backBtn = Ti.UI.createButton({
	image:'back.png',
	backgroundDisabledColor: true,
	backgroundImage: true,
	borderRadius: false,
	top: 3,
	left: 3,
	zIndex: 5
});
var nav = Ti.UI.createImageView ({
	image: 'bg-(2).png',
	top:0
});
backBtn.addEventListener('click', function(e){
	Ti.include('app.js');
	
}); 

/////LLIST////////////
var events = [

   
    {title:'Movember Party',leftImage: 'moemini.png', backgroundColor: 'white', test: 'poster.js' },
    {title:'View More', hasChild: true, backgroundColor: 'white', test: 'info.js'},
    

];

var table = Ti.UI.createTableView({
	data: events,
	top: 44,
	style:Titanium.UI.iPhone.TableViewStyle.GROUPED,
	backgroundColor: '#3f6c8e'
	

});
table.addEventListener('click', function(e)
{
	if (e.rowData.test)
	{
		var win = null;

			win = Titanium.UI.createWindow({
				url:e.rowData.test,
				title:e.rowData.title,
				zIndex: 5
				

			});
		win.open();
	}
	
	win.open();
});

var title = Ti.UI.createLabel({
	text: 'Events',
	color: 'white',
	top: 8,
	zIndex: 4,
	 font:{
                fontWeight:'bold',
                fontSize:20
            }
});
win.add(title);
win.add(table);
win.add(backBtn);
win.add(nav);
tabGroup.addTab(tab);
tabGroup.open({transition: Ti.UI.iPhone.AnimationStyle.FLIP_FROM_RIGHT});