var tabGroup = Ti.UI.createTabGroup();
 
var win = Ti.UI.createWindow({
    backgroundColor: '#3f6c8e',
    title:'Humber App',
    tabBarHidden:true,
    navBarHidden: true,
    barImage: '#3f6c8e',
    
    
    
});
 
 
var tab = Ti.UI.createTab({
    title:"Doesn't matter",
    window: win
});

var backBtn = Ti.UI.createButton({
	image:'back.png',
	backgroundDisabledColor: true,
	backgroundImage: true,
	borderRadius: false,
	top: 3,
	left: 3,
	zIndex: 5
});
var nav = Ti.UI.createImageView ({
	image: 'bg-(2).png',
	top:0
});
backBtn.addEventListener('click', function(e){
	Ti.include('updates.js')
}); 

var view = Ti.UI.createView ({
	
	width: 300,
	height: 175,
	backgroundColor: 'white',
	borderRadius: 10,
	shadow: 'black',
	top: 80
});

var view2 = Ti.UI.createView ({
	
	width: 300,
	height: 75,
	backgroundColor: 'white',
	borderRadius: 10,
	shadow: 'black',
	bottom: 60
});

var label = Ti.UI.createLabel ({
	text: 'Well my friends, it seems as if though our ever famous masscot man is getting a raise. Oh well, most students need to work hard to get a real job, but not this guy. He got a 20,000 dollar raise just for doing extra stunts at games. Life, when will it make sense?',
	font: {fontSize: 15},
	color: 'black',
	top: 3,
	left: 5,
	textAlign: 'left',
	
});
var label2 = Ti.UI.createLabel ({
		text: 'Call: 1-800-999-999-999',
	font: {fontSize: 15},
	color: 'black',
	
	textAlign: 'center',
})
win.add(view2);
view.add(label);
view2.add(label2)
win.add(view);

win.add(backBtn);
win.add(nav);
tabGroup.addTab(tab);
tabGroup.open({transition: Ti.UI.iPhone.AnimationStyle.FLIP_FROM_RIGHT});