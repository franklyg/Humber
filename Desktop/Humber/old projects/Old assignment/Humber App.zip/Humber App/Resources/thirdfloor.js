
var tabGroup = Ti.UI.createTabGroup();
 
var win = Ti.UI.createWindow({
    backgroundColor: '#FFF',
    title:'Classes',
   tabBarHidden: true,
   navBarHidden: true
    
    
    
});
 
 
var tab = Ti.UI.createTab({
    title:"1st Floor Classrooms",
    window: win,
    
});
 
tabGroup.addTab(tab);
tabGroup.open({transition: Ti.UI.iPhone.AnimationStyle.FLIP_FROM_RIGHT});
var floors = [
	
{title: 'E301' , header: 'E',test: 'mapE.js' },
{title: 'E303',test: 'mapE3.js'  },
{title: 'E305',test: 'mapE3.js'  },
{title: 'E307',test: 'mapE3.js'  },
{title: 'E310',test: 'mapE3.js'  },
{title: 'E315' ,test: 'mapE3.js' } ,
{title: 'E318' ,test: 'mapE3.js' },
{title: 'E321' ,test: 'mapE3.js' },
{title: 'E322' ,test: 'mapE3.js' },
{title: 'E324' ,test: 'mapE3.js' },
{title: 'E325' ,test: 'mapE3.js' },
{title: 'E327' ,test: 'mapE3.js' },
{title: 'E328' ,test: 'mapE3.js' },
{title: 'E332' ,test: 'mapE3.js' },
{title: 'E336' ,test: 'mapE3.js' },
{title: 'E338' ,test: 'mapE3.js' },
{title: 'E339' ,test: 'mapE3.js' },
{title: 'E341' ,test: 'mapE3.js' },
{title: 'E343' ,test: 'mapE3.js' },
{title: 'E344' ,test: 'mapE3.js' },
{title: 'E345' ,test: 'mapE3.js' },
{title: 'E346' ,test: 'mapE3.js' },
{title: 'GH301'  , header: 'GH', test:'mapGH3.js' },
{title: 'GH302', test:'mapGH3.js'  },
{title: 'GH303', test:'mapGH3.js'  },
{title: 'GH304', test:'mapGH3.js'  },
{title: 'GH312', test:'mapGH3.js'  },
{title: 'GH319', test:'mapGH3.js'  },
{title: 'GH321', test:'mapGH3.js'  },
{title: 'GH322', test:'mapGH3.js'  },
{title: 'GH323' , test:'mapGH3.js' },
{title: 'GH324', test:'mapGH3.js'  },
{title: 'GH325', test:'mapGH3.js'  },
{title: 'GH326', test:'mapGH3.js'  },

{title: 'H304'  , header: 'H', test:'mapH3.js'  },
{title: 'H316', test:'mapH3.js'  },
{title: 'H318', test:'mapH3.js'  },
{title: 'H324', test:'mapH3.js'  },
{title: 'H327', test:'mapH3.js'  },
{title: 'H329', test:'mapH3.js'  },
{title: 'H330', test:'mapH3.js'  },
{title: 'H334', test:'mapH3.js'  },



];
var table = Ti.UI.createTableView({
	data: floors,
	top: 44
	
});

table.addEventListener('click', function(e)
{
	if (e.rowData.test)
	{
		var win = null;

			win = Titanium.UI.createWindow({
				url:e.rowData.test,
				title:e.rowData.title,
				zIndex: 5
				

			});
		win.open();
	}
	
	win.open();
});
var backBtn = Ti.UI.createButton({
	image:'back.png',
	backgroundDisabledColor: true,
	backgroundImage: true,
	borderRadius: false,
	top: 3,
	left: 3,
	zIndex: 5
});
var nav = Ti.UI.createImageView ({
	image: 'bg-(2).png',
	top:0
});
backBtn.addEventListener('click', function(e){
	Ti.include('classrooms.js')
});
var title = Ti.UI.createLabel({
	text: 'Third Floor',
	color: 'white',
	top: 8,
	zIndex: 4,
	 font:{
                fontWeight:'bold',
                fontSize:20
            }
});
win.add(title);
win.add(table)
win.open();
win.add(nav);
win.add(backBtn)