var tabGroup = Ti.UI.createTabGroup();
 
var win = Ti.UI.createWindow({
    backgroundImage: 'bg-(1).jpg',
    title:'Humber App',
    tabBarHidden:true,
    navBarHidden: true,
    barImage: 'bg-(2).png'
    
});
 
 
var tab = Ti.UI.createTab({
    title:"Doesn't matter",
    window: win
});

var backBtn = Ti.UI.createButton({
	image:'back.png',
	backgroundDisabledColor: true,
	backgroundImage: true,
	borderRadius: false,
	top: 3,
	left: 3,
	zIndex: 5
});
var nav = Ti.UI.createImageView ({
	image: 'bg-(2).png',
	top:0
});
backBtn.addEventListener('click', function(e){
	Ti.include('app.js')
}); 


var tableRows = [{title: 'Parking Updates', test: 'park.js', hasChild: true},
				{ title: 'Get 30% off your tuition',test: '30p.js', hasChild: true},
				{title: 'Humber Masscot gets raise', test: 'mass.js', hasChild: true},
				{title: 'Yellow Taken Off Humber Uniform', test: 'yellow.js', hasChild: true}];
var table = Ti.UI.createTableView ({
	data: tableRows,
	top: 44
});

table.addEventListener('click', function(e)
{
	if (e.rowData.test)
	{
		var win = null;

			win = Titanium.UI.createWindow({
				url:e.rowData.test,
				title:e.rowData.title,
				zIndex: 5
				

			});
		win.open();
	}
	
	win.open();
});
var title = Ti.UI.createLabel({
	text: 'Updates',
	color: 'white',
	top: 8,
	zIndex: 4,
	 font:{
                fontWeight:'bold',
                fontSize:20
            }
});
win.add(title);
win.add(table)				
win.add(backBtn);
win.add(nav);
tabGroup.addTab(tab);
tabGroup.open({transition: Ti.UI.iPhone.AnimationStyle.FLIP_FROM_RIGHT});