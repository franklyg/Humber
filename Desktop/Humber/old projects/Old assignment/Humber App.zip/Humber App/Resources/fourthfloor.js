
var tabGroup = Ti.UI.createTabGroup();
 
var win = Ti.UI.createWindow({
    backgroundColor: '#FFF',
    title:'Classes',
   tabBarHidden: true,
   navBarHidden: true
    
    
    
});
 
 
var tab = Ti.UI.createTab({
    title:"1st Floor Classrooms",
    window: win,
    
});
 
tabGroup.addTab(tab);
tabGroup.open({transition: Ti.UI.iPhone.AnimationStyle.FLIP_FROM_RIGHT});
var floors = [
	
{title: 'E402' , header: 'E' },
{title: 'E404', test:'mapE4.js'  },
{title: 'E405', test:'mapE4.js'  },
{title: 'E407', test:'mapE4.js'  },
{title: 'E408', test:'mapE4.js'  },
{title: 'E409', test:'mapE4.js'  },
{title: 'E410', test:'mapE4.js'  },
{title: 'E411', test:'mapE4.js'  },
{title: 'E417', test:'mapE4.js'  },
{title: 'E422', test:'mapE4.js'  },
{title: 'E439', test:'mapE4.js'  },
{title: 'E440', test:'mapE4.js'  },
{title: 'E443', test:'mapE4.js'  },
{title: 'E445', test:'mapE4.js'  },
{title: 'E446', test:'mapE4.js'  },
{title: 'E451', test:'mapE4.js'  },
{title: 'E453', test:'mapE4.js'  },
{title: 'E455', test:'mapE4.js'  },
{title: 'E456', test:'mapE4.js'  },
{title: 'E458', test:'mapE4.js'  },
{title: 'GH411' , header: 'GH' , test:'mapGH4.js' },
{title: 'GH412', test:'mapGH4.js' },
{title: 'GH416', test:'mapGH4.js' },
{title: 'GH418', test:'mapGH4.js' },
{title: 'GH419', test:'mapGH4.js' },
{title: 'GH420', test:'mapGH4.js' },
{title: 'GH421', test:'mapGH4.js' },
{title: 'GH422', test:'mapGH4.js' },
{title: 'GH424', test:'mapGH4.js' },
{title: 'GH425', test:'mapGH4.js' },
{title: 'GH426', test:'mapGH4.js' },

{title: 'H407' , header: 'H', test:'mapH4.js' },
{title: 'H414' , test:'mapGH4.js'},
{title: 'H415' , test:'mapGH4.js'},
{title: 'H416', test:'mapGH4.js' },
{title: 'H419', test:'mapGH4.js' },
{title: 'H425', test:'mapGH4.js' },

];
var table = Ti.UI.createTableView({
	data: floors,
	top: 44
	
});
table.addEventListener('click', function(e)
{
	if (e.rowData.test)
	{
		var win = null;

			win = Titanium.UI.createWindow({
				url:e.rowData.test,
				title:e.rowData.title,
				zIndex: 5
				

			});
		win.open();
	}
	
	win.open();
});
var backBtn = Ti.UI.createButton({
	image:'back.png',
	backgroundDisabledColor: true,
	backgroundImage: true,
	borderRadius: false,
	top: 3,
	left: 3,
	zIndex: 5
});
var nav = Ti.UI.createImageView ({
	image: 'bg-(2).png',
	top:0
});
backBtn.addEventListener('click', function(e){
	Ti.include('classrooms.js')
});
var title = Ti.UI.createLabel({
	text: 'Fourth Floor',
	color: 'white',
	top: 8,
	zIndex: 4,
	 font:{
                fontWeight:'bold',
                fontSize:20
            }
});
win.add(title);
win.add(table)
win.open();
win.add(nav);
win.add(backBtn)