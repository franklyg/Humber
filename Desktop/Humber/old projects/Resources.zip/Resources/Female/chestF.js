var chestFemale = Ti.UI.currentWindow;
