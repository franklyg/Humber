var hisWin = Ti.UI.currentWindow;

hisWin.backgroundColor = 'red';
